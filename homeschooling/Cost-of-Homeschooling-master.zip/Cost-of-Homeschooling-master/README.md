# Cost of Homeschooling 

Article, data, and code for determining the effect of maternal education and household income on the odds of child homeschooling. Data from NCES. 

Languages: Stata, LaTeX (for drawing tables and compiling text)

Econometric Methods: Logistic regression with fixed effects


